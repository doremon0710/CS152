package value

import expression._
import system._

/**
  * Created by drproduck on 5/9/17.
  */
case class Boole(val value: Boolean) extends Literal {
  def ==(other: Boole) = Boole(value == other.value)
  override def toString = value.toString
}
