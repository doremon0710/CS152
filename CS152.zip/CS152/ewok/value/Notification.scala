package value

import expression._
import system._
/**
  * Created by drproduck on 5/9/17.
  */
class Notification(val msg: String) extends Value {
  override def toString = msg
}

object Notification {
  def apply(msg: String) = new Notification(msg)
  val OK = Notification("Ok")
  val DONE = Notification("Done")
  val UNSPECIFIED = Notification("Unspecified")
}