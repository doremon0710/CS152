package value

import expression._
import system._

import scala.collection.mutable

/**
  * Created by drproduck on 5/9/17.
  */
class Environment(var extension: Environment = null) extends mutable.HashMap[Identifier, Value] with Value {
  override def apply(name: Identifier): Value = {
    if (contains(name)) super.apply(name)
    else if (extension != null) extension(name)
    else throw new UndefinedException(name)
  }
}
