package system

import expression._
import value._

/**
  * Created by drproduck on 5/1/17.
  */
object alu {
  // dispatcher
  def execute(operator: Identifier, args: List[Value]): Value = {
    operator.name match {
      case "add" => add(args)
      case "sub" => sub(args)
      case "mul" => mul(args)
      case "div" => div(args)
      case "equals" => equal(args)
      case "less" => less(args)
      case "not" => not(args)
      case _ => throw new UndefinedException(operator)
    }
  }

  private def add(args: List[Value]): Number = {
    var nums = args.filter(_.isInstanceOf[Number])
    if (nums.length != args.length)
      throw new TypeException("Inputs to add must be numbers")
    val nums2 = nums.map(_.asInstanceOf[Number])
    nums2.reduce(_+_)
  }

  private def sub(args: List[Value]): Number = {
    var nums = args.filter(_.isInstanceOf[Number])
    if (nums.length != args.length)
      throw new TypeException("Inputs to sub must be numbers")
    val nums2 = nums.map(_.asInstanceOf[Number])
    nums2(0)*Number(2) - nums2.reduce(_+_)
  }

  private def mul(args: List[Value]): Number = {
    var nums = args.filter(_.isInstanceOf[Number])
    if (nums.length != args.length)
      throw new TypeException("Inputs to multiplication must be numbers")
    val nums2 = nums.map(_.asInstanceOf[Number])
    nums2.reduce(_*_)
  }

  private def div(args: List[Value]): Number = {
    var nums = args.filter(_.isInstanceOf[Number])
    if (nums.length != args.length)
      throw new TypeException("Inputs to sub must be numbers")
    val nums2 = nums.map(_.asInstanceOf[Number])
    nums2(0)*nums2(0) / nums2.reduce(_*_)
  }


  private def equal(args: List[Value]): Boole = {
    if (args(0).isInstanceOf[Boole]) {
      val bools = args.filter(_.isInstanceOf[Boole])
      if (bools.length != args.length)
        throw new TypeException("Inputs to '==' must be the same type")
      val bools2 = bools.map(_.asInstanceOf[Boole])
      Boole((bools2.forall(_.equals(bools2.head))))
    }
    else if (args(0).isInstanceOf[Number]) {
      val nums = args.filter(_.isInstanceOf[Number])
      if (nums.length != args.length)
        throw new TypeException("Inputs to '==' must be the same type")
      val nums2 = nums.map(_.asInstanceOf[Number])
      Boole(nums2.forall(_.equals(nums2.head)))
    }
    else throw new TypeException("Incompatible type for '==' operation")
  }

  private def less(args: List[Value]): Boole = {
    if (args.length != 2) throw new SyntaxException
    if (args(0).isInstanceOf[Number] && args(1).isInstanceOf[Number]) {
      val arg1 = args(0).asInstanceOf[Number]
      val arg2 = args(1).asInstanceOf[Number]
      arg1 < arg2
    }
    else throw new TypeException("Values to '<' must be numbers")
  }

  private def not(args: List[Value]): Boole = {
    if (args.length != 1) throw new SyntaxException
    if (args(0).isInstanceOf[Boole]) {
      val arg = args(0).asInstanceOf[Boole]
      Boole(!arg.value)
    }
    else throw new TypeException("Value to '!' must be Boole expression")
  }
}
