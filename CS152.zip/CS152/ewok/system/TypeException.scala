package system

import expression._
import value._
/**
  * Created by drproduck on 5/9/17.
  */
class TypeException(val msg: String) extends JediException(msg)
