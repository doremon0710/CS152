package system


import expression._
import value._
/**
  * Created by drproduck on 5/9/17.
  */
class JediException(val gripe: String = "Jedi exception") extends Exception(gripe)
