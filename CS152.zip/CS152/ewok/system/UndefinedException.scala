package system

import expression._
import value._
/**
  * Created by drproduck on 5/1/17.
  */
class UndefinedException(irritant: Identifier) extends JediException("Undefined Identifer: " + irritant.name)



