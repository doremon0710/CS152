package system

import expression._
import value._

import scala.util.parsing.combinator.RegexParsers

/**
  * Created by drproduck on 4/25/17.
  */
class EwokParsers extends RegexParsers {

  def expression: Parser[Expression] = declaration | conditional | disjunction | failure("Invalid expression")

  def declaration: Parser[Declaration] = "def" ~ identifier ~ "=" ~ expression ^^ {
    case "def" ~ name ~ "=" ~ body => Declaration(name, body)
  }

  def disjunction: Parser[Expression] = conjunction ~ rep("||" ~> conjunction) ^^ {
    case con ~ Nil => con
    case con ~ con1 => Disjunction(con :: con1)
  }

  def conjunction: Parser[Expression] = equality ~ rep("&&" ~> equality) ^^ {
    case eq ~ Nil => eq
    case eq ~ eq1 => Conjunction(eq::eq1)
  }

  def equality:    Parser[Expression] = inequality ~ rep("==" ~> inequality) ^^ {
    case ineq ~ Nil => ineq
    case ineq ~ ineqs => FunCall(Identifier("equals"), ineq::ineqs)
  }

  def inequality:  Parser[Expression] = sum ~ opt("<" ~> sum) ^^ {
    case s ~ None => s
    case s ~ Some(s2) => FunCall(Identifier("less"), s::s2::Nil)
  }

  def sum: Parser[Expression] = product ~ rep(("+" | "-") ~ product ^^ { case "+" ~ s => s case "-" ~ s => negate(s) }) ^^ {
    case p ~ Nil => p
    case p ~ rest => FunCall(Identifier("add"), p :: rest)
  }

  def product: Parser[Expression] = term ~ rep(("*" | "/") ~ term ^^ { case "*" ~ f => f case "/" ~ f => inverse(f) }) ^^ {
    case t ~ Nil => t
    case t ~ rest => FunCall(Identifier("mul"), t :: rest)
  }

  def term: Parser[Expression] = lambda | block | number | boole | funcall | identifier | "(" ~ expression ~ ")" ^^ {
    case "(" ~ exp ~ ")" => exp
  }

  def funcall: Parser[Expression] = identifier ~ opt(operands) ^^ {
    case t ~ None => t
    case t ~ Some(ops) => FunCall(t, ops)
  }

  def operands: Parser[List[Expression]] = "(" ~ opt(expression ~ rep("," ~> expression)) ~ ")" ^^ {
    case "(" ~ None ~ ")" => List.empty
    case "(" ~ Some(exp ~ Nil) ~ ")" => exp :: Nil
    case "(" ~ Some(exp ~ exps) ~ ")" => exp :: exps
  }

  def identifier: Parser[Identifier] =
    """[a-zA-Z][a-zA-Z0-9]*""".r ^^ {
      case name => Identifier(name)
    }

  def number: Parser[Number] =
    """((\+|-)?([0-9]+)(\.[0-9]+)?)|((\+|-)?\.?[0-9]+)""".r ^^ {
      case num => Number(num.toDouble)
    }

  def boole: Parser[Boole] = ("true" | "false") ^^ {
    case value => if (value == "true") Boole(true) else Boole(false)
  }

  def conditional: Parser[Expression] = "if" ~ "(" ~ expression ~ ")" ~ expression ~ opt("else" ~> expression) ^^ {
    case "if" ~ "(" ~ con ~ ")" ~ exp1 ~ None => Conditional(con, exp1)
    case "if" ~ "(" ~ con ~ ")" ~ exp1 ~ Some(exp2) => Conditional(con, exp1, Option(exp2))
  }

  private def negate(exp: Expression): Expression = {
    val sub = Identifier("sub")
    val zero = Number(0)
    FunCall(sub, List(zero, exp))
  }

  private def inverse(exp: Expression): Expression = {
    val div = Identifier("div")
    val one = Number(1)
    FunCall(div, List(one, exp))
  }

  def block: Parser[Expression] = "{" ~ expression ~ rep(";" ~> expression) ~ "}" ^^ {
    case "{" ~ exp ~ Nil ~ "}" => exp
    case "{" ~ exp ~ more ~ "}" => Block(exp :: more)
  }

  def lambda: Parser[Expression] = "lambda" ~ parameters ~ expression ^^{
    case "lambda" ~ params ~ exp => Lambda(params, exp)
  }
  def parameters: Parser[List[Identifier]] = "(" ~> opt(identifier ~ rep("," ~> identifier)) <~ ")" ^^ {
    case None => Nil
    case Some(e ~ Nil) => List(e)
    case Some(e ~ exps) => e :: exps
    case _ => Nil
  }

}