package expression

import value._
import system._
/**
  * Created by drproduck on 5/9/17.
  */
case class Disjunction(val exps: List[Expression]) extends SpecialForm {
  def execute(env: Environment): Value = {

    def helper(count: Int): Boole = {
      if (count == exps.length) Boole(false)
      else {
        val current = exps(count).execute(env)
        if (!current.isInstanceOf[Boole])
          throw new TypeException("Input must be Boole for '||' operation")
        else if (current.asInstanceOf[Boole].value == true) Boole(true)
        else helper(count + 1)
      }
    }
    helper(0)
  }
}
