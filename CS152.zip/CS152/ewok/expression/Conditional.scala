package expression

import value._
import system._

/**
  * Created by drproduck on 5/9/17.
  */
case class Conditional(val exp0: Expression, val exp1: Expression, val exp2: Option[Expression] = None) extends SpecialForm {
  def execute(env: Environment): Value = {
    val condition = exp0.execute(env)
    if (!condition.isInstanceOf[Boole]) throw new TypeException("Conditional statement requires boole value")
    else {
      val value = condition.asInstanceOf[Boole]
      if (value.value == true) exp1.execute(env)
      else if (exp2.isEmpty) Notification.UNSPECIFIED
      else exp2.get.execute(env)
    }
  }
}
