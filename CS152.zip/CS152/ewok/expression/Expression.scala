package expression

import value._
import system._

/**
  * Created by drproduck on 5/1/17.
  */
trait Expression {
  def execute(env: Environment): Value
}
