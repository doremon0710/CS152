package expression

import value._
import system._

/**
  * Created by drproduck on 5/9/17.
  */
trait Literal extends   Value with Expression {
  def execute(env: Environment) = this
}
