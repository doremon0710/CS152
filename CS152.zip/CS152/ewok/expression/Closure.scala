package expression

import system._
import value._

class Closure(params: List[Identifier], body: Expression, defEnv: Environment) extends Value {
  def apply(args: List[Value]): Value = {
    val tempEnv = new Environment(defEnv)
    if (params.length != args.length) throw new TypeException("numbers of parameters and arguments must match")
    else {
      for (i <- 0 until params.length){
        tempEnv.put(params(i), args(i))
      }
      body.execute(tempEnv)
    }
  }
}
