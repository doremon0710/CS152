package expression

import value._
import system._

/**
  * Created by drproduck on 5/9/17.
  */
case class Identifier(val name: String) extends Expression {
  def execute(env: Environment): Value = env(this)
}
