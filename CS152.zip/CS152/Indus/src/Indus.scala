import scala.collection.mutable.ArrayBuffer

/**
  * Created by drproduck on 4/12/17.
  */
object Indus {
  def main(args: Array[String]): Unit = {
    var inventory = ArrayBuffer[Item]()
    inventory += Item(Description("The Matrix DVD", 15.5, "DVD World"), 5)
    inventory += Item(Description("The Terminator DVD", 13.25, "DVD World"), 3)
    inventory += Item(Description("Ironman", 18.00, "DVD Planet"), 2)

    inventory.foreach(item => print(item.toString))

  }
}

class Description(description: String, price: Double, supplier: String) {
  override def toString: String = "description: %s\nPrice: %.2f\nSuppiler: %s\n".format(description, price, supplier)
}

object Description {
  def apply(description: String, price: Double, supplier: String): Description = new Description(description, price, supplier)
}

class Item(description: Description, amount: Int) {
  Item.nextId += 1
  var id = Item.nextId

  override def toString: String = "id: %d\n# in stock: %d\n%s\n".format(id, amount, description)
}

object Item {
  var nextId = 0;

  def apply(description: Description, amount: Int): Item = new Item(description, amount)
}
