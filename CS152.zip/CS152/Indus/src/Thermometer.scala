/**
  * Created by drproduck on 4/12/17.
  */
object Thermometer {
  def main(args: Array[String]): Unit = {
    val a = new Adapter
    println(a.getMeanTemperature(List("1", "2", "3", "4")))
  }
}

trait IThermometer {
  // = avg degrees Farenheit
  def getMeanTemperature(cities: List[String]): Double
}

class CenTherm {
  // = degrees Centigrade
  def computeTemp(city: String) = city.toDouble
}

class Adapter extends IThermometer {

  val therm = new CenTherm

  override def getMeanTemperature(cities: List[String]) = {
    cities.foldLeft(0.0)((a, b) => a + therm.computeTemp(b)) / cities.length
  }
}