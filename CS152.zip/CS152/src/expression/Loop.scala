package expression

import value._
import system._

case class Loop(count: Expression, body: Expression) extends SpecialForm {
  override def execute(env: Environment): Value = {
    val c1 = count.execute(env)
    if (!c1.isInstanceOf[Number]) throw new system.TypeException("count must be a number")
    val c2 = c1.asInstanceOf[Number].value
    if (c2 - c2.toInt != 0.0 || c2 < 0) throw new system.TypeException("count must be a postitive integer")
    val c3 = c2.asInstanceOf[Int]
    for (i <- 0 until c3) body.execute(env)
    Notification.DONE
  }
}

