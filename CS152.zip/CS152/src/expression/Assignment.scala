package expression

import value._
import system._

/**
  * Created by drproduck on 5/16/17.
  */
case class Assignment(val vbl: Identifier, val update: Expression) extends SpecialForm {
  override def execute(env: Environment): Value = {
    try {
      val newValue = update.execute(env)
      val variable = vbl.execute(env)
      variable.asInstanceOf[Variable].content = newValue
    } catch {
      case e: ClassCastException => throw new system.TypeException(vbl.name+" is not a variable")
    }
    Notification.DONE
  }
}
