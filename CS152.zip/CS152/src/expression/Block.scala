package expression
import value._
import system._

/**
  * Created by drproduck on 5/9/17.
  */
case class Block(locals: List[Expression]) extends SpecialForm{
  override def execute(env: Environment): Value = {
    val localEnv = new Environment(env)
    for (i <- 0 until locals.length-1) {
      locals(i).execute(localEnv)
    }
    locals(locals.length-1).execute(localEnv)
  }
}
