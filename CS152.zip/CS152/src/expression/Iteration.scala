package expression

import system._
import value._

/**
  * Created by drproduck on 5/16/17.
  */
case class Iteration(val condition: Expression, val body: Expression, testAtTop: Boolean = true) extends SpecialForm {
  override def execute(env: Environment): Value = {
    if (!condition.execute(env).isInstanceOf[Boole]) throw new system.TypeException("condition must be of type boolean")
    val cond = condition.execute(env).asInstanceOf[Boole].value
    if (!testAtTop) while (cond) body.execute(env)
    else {
      body.execute(env)
      while(cond) body.execute(env)
    }
    Notification.DONE
  }
}
