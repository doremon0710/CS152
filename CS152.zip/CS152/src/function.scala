/**
  * Created by drproduck on 5/21/17.
  */
object function {
  def combinator(f: Int => Int, g: Int => Int): Int => Int = {
    def h(x: Int): Int = {
      f(g(x))
    }

    h
  }

  def main(args: Array[String]): Unit = {
    val g = (x: Int) => x + 3
    val h = (x: Int) => x * 2
    val k = combinator(h, g)
    println(k(5))
  }
}


