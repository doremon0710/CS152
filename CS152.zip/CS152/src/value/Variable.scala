package value
import system._
import expression._

/**
  * Created by drproduck on 5/16/17.
  */
case class Variable(var content: Value) extends Value{

}
