package system

class TypeException(gripe: String = "Type Error") extends JediException(gripe)
  
