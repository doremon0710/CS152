/**
  * Created by drproduck on 4/25/17.
  */
object main {
  def main(args: Array[String]): Unit = {
    (true || {println("haha"); false})
    (true && {println("haha");false})
    true && 3

  }
}
