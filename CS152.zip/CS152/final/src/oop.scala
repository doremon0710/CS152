/**
  * Created by drproduck on 5/21/17.
  */

trait Attacker {
  def attack(victim: Avatar) {}
}

trait Flamer extends Attacker {
  override def attack(victim: Avatar) {
    println("flaming " + victim.name)
    super.attack(victim)
  }
}

trait Poisoner extends Attacker {
  override def attack(victim: Avatar) {
    println("poisoning " + victim.name)
    super.attack(victim)
  }
}

trait Stomper extends Attacker {
  override def attack(victim: Avatar) {
    println("stomping " + victim.name)
    super.attack(victim)
  }
}

class Avatar(val name: String) extends Attacker {
  def fight(victim: Avatar) {
    println(name + " is fighting " + victim.name)
    attack(victim)
  }
}

object Battle extends App {
  val shera = new Avatar("She-Ra") with Poisoner with Flamer
  val skeletor = new Avatar("Skeletor") with Stomper with Poisoner
  shera.fight(skeletor)
  skeletor.fight(shera)
}

