/**
  * Created by drproduck on 5/22/17.
  */

import scala.io._
import scala.util.parsing.combinator._

// TO DO: Complete this declaration:

trait Expression {
  def execute: Double
}

case class Sum(product: Product, sum: Sum = null) extends Expression {
  override def execute: Double = if (sum != null) product.execute + sum.execute else product.execute
}

case class Product(num: Number, product: Product = null) extends Expression {
  override def execute: Double = if (product != null) num.execute * product.execute else num.execute
}

case class Number(num: Double) extends Expression {
  override def execute: Double = num
}

object sopParsers extends RegexParsers {

  def sum: Parser[Sum] = product ~ opt("+" ~> sum) ^^ {
    case product ~ None => Sum(product)
    case product ~ Some(sum) => Sum(product, sum)
  }

  def product: Parser[Product] = number ~ opt("*" ~> product) ^^ {
    case number ~ None => Product(number)
    case number ~ Some(product) => Product(number, product)
  }

  def number: Parser[Number] = """(0|[1-9][0-9]*)(\.[0-9]+)?""".r ^^ { case num => Number(num.toDouble) }
}

class SyntaxException(val result: Parsers#Failure = null) extends Exception("Syntax error")

object console {

  def execute(cmmd: String): String = {
    val tree = sopParsers.parseAll(sopParsers.sum, cmmd)
    tree match {
      case tree: sopParsers.Failure => throw new SyntaxException(tree)
      case _ => {
        val exp = tree.get
        // get the expression from the tree
        val result = exp.execute // execute the expression
        result.toString // return string representation of result
      }
    }
  }

  def repl {
    var more = true
    var cmmd = ""
    while (more) {
      try {
        print("-> ")
        cmmd = StdIn.readLine
        if (cmmd == "quit") more = false
        else println(execute(cmmd))
      }
      catch {
        case e: SyntaxException => {
          println(e)
          println(e.result.msg)
          println("line # = " + e.result.next.pos.line)
          println("column # = " + e.result.next.pos.column)
          println("token = " + e.result.next.first)
        }
        case e: Exception => {
          println(e)
        }
      }
    }
    println("bye")
  }

  def main(args: Array[String]): Unit = {
    repl
  }

}
