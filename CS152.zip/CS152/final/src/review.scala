/**
  * Created by drproduck on 5/21/17.
  */
object review {
  def cond[A, B](test: A=> Boolean, branch1: A => B, branch2: A => B): A => B ={
    def f(x: A): B = {
      if (test(x)) branch1(x) else branch2(x)
    }
    f
  }

  def map[T](array: Array[T], test: T => Boolean, transform: T => T) {
    val l = array.length
    def helper(count: Int) {
      if (count < l) {
        if (test(array(count)))
        array(count) = transform(array(count))
        helper(count+1)
      }
    }
    helper(0)
    println((array).mkString(", "))
  }

  def tester[T, S](f: T=>S, inputs: Array[T], outputs: Array[S]): Int = {
    val l1 = inputs.length
    val l2 = outputs.length
    if (l1 != l2) throw new Exception
    var count = 0
    def helper(index: Int) {
      if (index < l1) {
        if (f(inputs(index)) != outputs(index)) {
          count += 1
        }
        helper(index + 1)
      }
    }
    helper(0)
    count
  }

  def main(args: Array[String]): Unit = {
    val jump = cond((x: Int) => x%2==0, (x:Int) => x*x, (x: Int) => x*x*x)
    println(jump(3))
    println(jump(4))

    val nums = Array(-3, 2, 6, -4, 9, 0, -8, 9)
    map(nums, (x: Int) => x < 0, (x: Int) => math.abs(x).toInt)

    def isPower2(n: Int) = n % 2 == 0 && n/2 % 2 == 0
    println(tester(isPower2 _, Array(2, 4, 6, 8, 10, 12, 32), Array(true, true, false, true, false, false, true))) // = 2)
  }
}
