/**
 * Created by drproduck on 5/21/17.
 */
public class test {
    public static void main(String[] args) {
        int a = 2, b = 3;
        Wrap x = new Wrap(a);
        Wrap y = new Wrap(b);
        swap(x, y);
        System.out.println(x.x);
        System.out.println(y.x);
    }

    public static void swap(Wrap a, Wrap b) {
        int x = a.x;
        int y = b.x;

        x = x + y;
        b.x = x - y;
        a.x = x - b.x;
    }
}

class Wrap {
    int x;
    Wrap(int a) {
        x = a;
    }
}