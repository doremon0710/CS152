/**
  * Created by drproduck on 4/12/17.
  */
object Dungeon {
  def main(args: Array[String]): Unit = {
    val random = new scala.util.Random(System.nanoTime())
    val k = new Knight("silly knight")
    val d = new Dragon("brave dragon")
    var stop: Boolean = false
    while (!stop) {
      stop = (k.attack(d, random.nextDouble) || d.attack(k, random.nextDouble))
    }
    println("%s's health: %.2f".format(k.name, k.health))
    println("%s's health: %.2f".format(d.name, d.health))
    if (k.health==0) println("%s wins".format(k.name)) else println("%s wins".format(d.name))
  }
}

class Dragon(private val _name: String = "Dragon") {
  var health: Double = 100
  def name = _name
  def attack(victim: Knight, dmg: Double): Boolean = {
    if (health <= 0 || victim.health <= 0) {
      true
    } else {
      printf("%s is flaming %s\n", _name, victim.name)
      if (dmg > victim.health) victim.health = 0
      else victim.health -= dmg
      false
    }
  }
}

class Knight(private val _name: String = "Knight") {
  var health: Double = 100
  def name = _name
  def attack(victim: Dragon, dmg: Double): Boolean = {
    if (health <= 0 || victim.health <= 0) {
      true
    } else {
      printf("%s is stabbing %s\n", _name, victim.name)
      if (dmg > victim.health) victim.health = 0
      else victim.health -= dmg
      false
    }
  }
}
